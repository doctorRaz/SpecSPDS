﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

//==============================================================================
struct mcsArrow
{
	mcsPoint  pnt;
	mcsVector dir;
	mcsVector normal;
	MCS_ARROW eType;
	double    rSize;
	double    rWidth;

	DECLARE_OBJ_NEWDEL;

	MCTYP_API mcsArrow();
	MCTYP_API ~mcsArrow();
	MCTYP_API mcsArrow(const mcsPoint& _pnt, const mcsVector& _dir, MCS_ARROW _eType, double _rSize, double _rWidth = 0);
	MCTYP_API mcsArrow(const mcsPoint& _pnt, const mcsVector& _dir, const mcsVector& _normal, MCS_ARROW _eType, double _rSize, double _rWidth = 0);

	MCTYP_API bool operator == (const mcsArrow& t) const;
	MCTYP_API bool isEqualTo(const mcsArrow& cw, const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API mcsArrow& operator =(const mcsArrow& src);

	bool operator != (const mcsArrow& trg) const
	{
		return !operator == (trg);
	}

	MCTYP_API void          transformBy(const mcsMatrix& tfm);
	MCTYP_API mcsBoundBlock getBoundBlock(bool isOrtho = false) const;
	MCTYP_API bool          intersectBy(const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          intersectBy(const McsEntityGeometry& otherEnt, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          asLineSeg(OUT mcsLineSeg& ls) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
};

typedef McsArray<mcsArrow, const mcsArrow&> mcsArrowsArray;



//==============================================================================
// represents dimension arrows for linear and angular dimensions
struct mcsDimArrow
{
	mcsLineSeg m_ls;
	mcsCircArc m_ca;
	mcsVector  m_normal; // only for linear type
	bool       m_fLinear;
	bool       m_fEnd1, m_fEnd2;
	McsString  m_text;
	color_t    m_textColor; // color for dim text, by def may be black or white, or black/white
	byte       m_textHeight; // in pixels, 0 - default

	//.........................................................
	DECLARE_OBJ_NEWDEL;

	MCTYP_API mcsDimArrow();
	MCTYP_API ~mcsDimArrow();

	MCTYP_API void setLinear(
		const mcsLineSeg& ls,
		bool fEnd1,
		bool fEnd2,
		IN OPTIONAL LPCTSTR text = NULL,
		IN OPTIONAL const mcsVector& normal = mcsVector::kZAxis,
		IN OPTIONAL color_t textColor = COLORREF_SPEC_VAL,
		IN OPTIONAL byte textHeight = 0);

	MCTYP_API void setAngular(
		const mcsCircArc& ca,
		bool fEnd1,
		bool fEnd2,
		IN OPTIONAL LPCTSTR text = NULL,
		IN OPTIONAL color_t textColor = COLORREF_SPEC_VAL,
		IN OPTIONAL byte textHeight = 0);

	MCTYP_API mcsDimArrow& operator = (const mcsDimArrow& cf);
	MCTYP_API bool operator == (const mcsDimArrow& cw) const;
	MCTYP_API bool operator != (const mcsDimArrow& cw) const;
	MCTYP_API bool isEqualTo(const mcsDimArrow& cw, const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API void transformBy(const mcsMatrix& tfm);

	MCTYP_API mcsBoundBlock getBoundBlock(bool isOrtho = false) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
};

typedef McsArray<mcsDimArrow, const mcsDimArrow&> mcsDimArrowsArray;