﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

//==============================================================================
class mcsGeomEntArray : public McsArray<McsEntityGeometry, const McsEntityGeometry&>
{
protected:
	bool m_bAddContentsToExternalStorage;

public:
	DECLARE_OBJ_NEWDEL;

	mcsGeomEntArray()
	{
		m_bAddContentsToExternalStorage = false;
	}

	MCTYP_API bool isEqualTo(const mcsGeomEntArray& cw, const mcsTol& tol = mcsGeContext::gTol, IN OPTIONAL bool fCmpGeomOnly = false) const;
	MCTYP_API bool transformBy(const mcsMatrix& tfm);

	MCTYP_API bool init(int nNewSize, EntityGeometryTypeEnum elementsType);

	MCTYP_API void setVisible(bool fVisible);
	MCTYP_API void setTransparency(int iTransparency); // 0..100, 0 = opaque/visible, 100 = completely transparent/invisible
	MCTYP_API void setColor(color_t newColor);
	MCTYP_API void setLineWeight(int iLineWeight);
	MCTYP_API void setLineType(int lt);

	MCTYP_API mcsBoundBlock getBoundBlock(bool bIncludeAxis = false) const;
	MCTYP_API mcsBoundBlock getOrthoBoundBlock() const;

	MCTYP_API bool areEquAs3dNodes(IN const mcsGeomEntArray& cw, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol, IN OPTIONAL bool fCmpGeomOnly = false) const;

	//................................................................
	// returns <0 if not found
	MCTYP_API int getNearestEnt(const mcsPoint& pickPoint, OUT OPTIONAL double* pDistance = NULL) const;

	// Ru:
	//    Матрица проекции должна быть задана для плоскости XY, т.к. после проекции Z игнорируется.
	//    (!) Матрица должна быть обратима.
	// En:
	//    The projection matrix must be defined for the XY plane, since Z is ignored after projection.
	//    (!) The matrix must be invertible.
	MCTYP_API int getNearestEnt(const mcsPoint& pickPoint, IN OPTIONAL const mcsMatrix* pXyProjTfm) const;

	MCTYP_API bool getNearestEnt(McsEntityGeometry& simpleEnt, const mcsPoint& pickPoint) const;

	// Ru:
	//    Тест селекции лучом, результат true, если хоть один элемент в массиве попадает в луч.
	// En:
	//    Beam selection test, returns true if at least one element in the array is within the beam.
	MCTYP_API bool hitTest(
		const mcsPoint& pt,
		const mcsVector& vDir,
		bool             bCheckBothDirs = true, // Ru: проверять ли также направление, обратное данному / En: check also the reverse direction of the given one
		double           rRay = -1) const; // Ru: по умолчанию используется системная апертура в активном документе / En: by default, the system aperture in the active document is used

	MCTYP_API int getNearestEntAmongClosest(const mcsPoint& pickPoint, double dMaxDist, OUT OPTIONAL double* pDistance) const;

	// Ru:
	//    Матрица проекции должна быть задана для плоскости XY, т.к. после проекции Z игнорируется.
	//    (!) Матрица должна быть обратима.
	// En:
	//    The projection matrix must be defined for the XY plane, since Z is ignored after projection.
	//    (!) The matrix must be invertible.
	MCTYP_API int getNearestEntAmongClosest(
		const mcsPoint& pickPoint,
		IN OPTIONAL const mcsMatrix* pXyProjTfm,
		double                       dMaxDist,
		OUT OPTIONAL double* pDistance) const;

	MCTYP_API void clearExProperties();

	MCTYP_API int findByGSMarker(__int64 iGSMarker);

	void setAddContentsFlag(bool bAdd) {
		m_bAddContentsToExternalStorage = bAdd;
	}

	bool doAddContents() const {
		return m_bAddContentsToExternalStorage;
	}
};