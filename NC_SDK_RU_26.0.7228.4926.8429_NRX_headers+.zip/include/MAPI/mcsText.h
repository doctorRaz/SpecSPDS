﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//
#pragma once

#ifdef _VERBOSEHEADERS_
#pragma message("Use " __FILE__)
#endif

#define MCSTEXT_DEFOBLIQUE -10

class mcsGeomEntArray;

enum McsHorizTextAlignEnum
{
	kTextHorizAlign_Left = 0,
	kTextHorizAlign_Center = 1,
	kTextHorizAlign_Right = 2
};
//==================================================================================================

enum McsVertTextAlignEnum
{
	kTextVertAlign_Top = 0,
	kTextVertAlign_Center = 1,
	kTextVertAlign_Bottom = 2
};
//==================================================================================================

// Ru:
//    В размерных стилях используется следующий порядок, нежели McsVertTextAlignEnum.
//    Однако в старые форматы стрима писалось McsVertTextAlignEnum.
// En:
//    In dimensional styles, the following order is used, rather than McsVertTextAlignEnum.
//    However, McsVertTextAlignEnum was written to old stream formats.
enum McsDimTolVertJustifyEnum
{
	kMcsDimTolVertJustify_Bottom = 0,
	kMcsDimTolVertJustify_Middle = 1,
	kMcsDimTolVertJustify_Top = 2,
};
//==================================================================================================

inline McsDimTolVertJustifyEnum cvtVertAlign(IN McsVertTextAlignEnum eVert) { return (McsDimTolVertJustifyEnum)(2 - int(eVert)); }
inline McsVertTextAlignEnum cvtVertAlign(IN McsDimTolVertJustifyEnum eVert) { return (McsVertTextAlignEnum)(2 - int(eVert)); }

//==============================================================================

struct mcsText
{
private:
	McsString m_text;
	McsString m_textStyle;             // If empty - default textstyle by context
	mcsPoint m_origin;                 // Text location
	mcsVector m_direction;             // Text direction
	mcsVector m_normal;                // Text normal
	McsHorizTextAlignEnum m_horizAlign;// Horizontal alignment
	McsVertTextAlignEnum m_vertAlign;  // Vertical alignment
	double m_width;                    // Used during word wrap. If 0 - no word wrap
	double m_height;                   // If 0 - by textStyle
	double m_oblique;                  // Oblique in radians. If MCSTEXT_DEFOBLIQUE - by textStyle. Ignored in MText
	double m_xScale;                   // If 0 - by textStyle. Ignored in MText
	double m_lineSpacing;              // Line spacing
	double m_hostScale;                // Text's host scale
	double m_rotation;
	bool m_isWordWrap;
	bool m_isMText;

public:
	uint32_t                             m_Flags;
#define    MCSTEXT_DEPRECATED        0x80000000     // Text parameters has changed
	// Ru:
	//    Более не используется. Теперь работаем через свойство геометрии kMcGeomExPropUseOwnStyle
	// En:
	//    No longer used. Now working through the geometry property kMcGeomExPropUseOwnStyle
	//#define    MCSTEXT_STYLE_OVERRIDE    0x40000000     // Use style settings (color, line weight and type) directly from exploded
#define    MCSTEXT_MASK_BACKGROUND   0x20000000     // Fill text boundaries with background color
#define    MCSTEXT_ALIGNED_TO_CAMERA 0x10000000     // Draws the text in a plane that's parallel to the camera

	mcsGeomEntArray exploded;
	mcsPoint        boundBase;
	double          boundX;
	double          boundY;

	DECLARE_OBJ_NEWDEL;

	MCTYP_API mcsText();
	MCTYP_API ~mcsText();

	MCTYP_API mcsText(
		LPCTSTR _text,
		const mcsPoint& _origin,
		const mcsVector& _direction,
		const McsHorizTextAlignEnum _horizAlign = kTextHorizAlign_Left,
		const McsVertTextAlignEnum _vertAlign = kTextVertAlign_Bottom,
		LPCTSTR _textStyle = NULL,
		const double _height = 0,
		const double _width = 0);

	MCTYP_API mcsText(
		LPCTSTR _text,
		const mcsPoint& _origin,
		const mcsVector& _direction,
		LPCTSTR _textStyle = NULL,
		const double _height = 0,
		const double _oblique = MCSTEXT_DEFOBLIQUE,
		const double _xScale = 0);

	MCTYP_API bool operator ==(const mcsText& trg) const;
	MCTYP_API bool isEqualTo(const mcsText& cw, const mcsTol& tol = mcsGeContext::gTol) const;

	bool operator != (const mcsText& trg) const
	{
		return !operator == (trg);
	}

	MCTYP_API void transformBy(const mcsMatrix& tfm);
	MCTYP_API mcsBoundBlock getBoundBlock(bool isOrtho = false) const;
	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
	MCTYP_API McsString textRaw() const; // Ru: текст без rtf-форматирования / En: text without rtf formatting
	MCTYP_API void Prepare(mcsBoundBlock* pBound); // Ru: разбивает текст на примитивы и складывает в exploded / En: splits text into primitives and stores them in exploded
	MCTYP_API bool GetContour(mcsPolyline& contour, double rOffset) const; // Ru: контур маскировки\перекрытия / En: masking/overlap contour
	MCTYP_API bool GetContour(mcsPoint* pRectangle, double rOffset) const; // Ru: контур маскировки\перекрытия, pRectangle - указатель на массив из четырёх точек / En: masking/overlay contour, pRectangle - pointer to an array of four points
	MCTYP_API bool GetFragmentBounds(int iStart, int iEnd, mcsBoundBlocksArray& bounds) const; // Ru: Габариты фрагмента от iStart символа до iEnd в простом тексте. Например для подсветки фрагмента. / En: The dimensions of the fragment from the iStart character to iEnd in plain text. For example, for highlighting a fragment.
	MCTYP_API int HitTest(const mcsPoint& pnt) const; // Ru: Номер символа по точке. / En: Character number by point.

	MCTYP_API bool IsEmpty() const
	{
		return m_text.IsEmpty();
	}

	MCTYP_API int GetLength() const
	{
		return m_text.GetLength();
	}

	bool getMaskBackground() const
	{
		return 0 != (m_Flags & MCSTEXT_MASK_BACKGROUND);
	}

	void setMaskBackground(bool b)
	{
		if (b)
			m_Flags |= MCSTEXT_MASK_BACKGROUND;
		else
			m_Flags &= !MCSTEXT_MASK_BACKGROUND;
		m_Flags |= MCSTEXT_DEPRECATED;
	}

	bool getAlignedToCamera() const
	{
		return 0 != (m_Flags & MCSTEXT_ALIGNED_TO_CAMERA);
	}

	void setAlignedToCamera(bool b)
	{
		if (b)
			m_Flags |= MCSTEXT_ALIGNED_TO_CAMERA;
		else
			m_Flags &= !MCSTEXT_ALIGNED_TO_CAMERA;
		m_Flags |= MCSTEXT_DEPRECATED;
	}

	// Inline property helpers
	const McsString& getText() const { return m_text; }
#if defined(WIN64) || defined(MCS64)
	TCHAR                       getText(int Index) const { return m_text[Index]; }
#endif
	TCHAR                       getText(INT_PTR Index) const { return m_text[(int)Index]; }
	void                        setText(const McsString& Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_text != Value) { m_text = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	void                        setText(TCHAR Value) { if (m_text.GetLength() != 1 || m_text[0] != Value) { m_text = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	const McsString& getTextStyle() const { return m_textStyle; }
	void                        setTextStyle(const McsString& Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_textStyle != Value) { m_textStyle = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	const mcsPoint& getOrigin() const { return m_origin; }
	void                        setOrigin(const mcsPoint& Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_origin != Value) { m_origin = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	const mcsVector& getDirection() const { return m_direction; }
	void                        setDirection(const mcsVector& Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_direction != Value) { m_direction = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	const mcsVector& getNormal() const { return m_normal; }
	void                        setNormal(const mcsVector& Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_normal != Value) { m_normal = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	McsHorizTextAlignEnum       getHorizAlign() const { return m_horizAlign; }
	void                        setHorizAlign(McsHorizTextAlignEnum Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_horizAlign != Value) { m_horizAlign = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	McsVertTextAlignEnum        getVertAlign() const { return m_vertAlign; }
	void                        setVertAlign(McsVertTextAlignEnum Value) { if ((m_Flags & MCSTEXT_DEPRECATED) || m_vertAlign != Value) { m_vertAlign = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getWidth() const { return m_width; }
	void                        setWidth(double Value) { if (!EQU(Value, m_width)) { m_width = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getHeight() const { return m_height; }
	void                        setHeight(double Value) { if (!EQU(Value, m_height)) { m_height = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getOblique() const { return m_oblique; }
	void                        setOblique(double Value) { if (!EQU(Value, m_oblique)) { m_oblique = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getXScale() const { return m_xScale; }
	void                        setXScale(double Value) { if (!EQU(Value, m_xScale)) { m_xScale = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getLineSpacing() const { return m_lineSpacing; }
	void                        setLineSpacing(double Value) { if (!EQU(Value, m_lineSpacing)) { m_lineSpacing = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	bool                        getWordWrap() const { return m_isWordWrap; }
	void                        setWordWrap(bool Value) { if (Value != m_isWordWrap) { m_isWordWrap = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getHostScale() const { return m_hostScale; }
	void                        setHostScale(double Value) { if (!EQU(Value, m_hostScale)) { m_hostScale = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	bool                        getMText() const { return m_isMText; }
	void                        setMText(bool Value) { if (Value != m_isMText) { m_isMText = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
	double                      getRotation() const { return m_rotation; }
	void                        setRotation(double Value) { if (!EQU(Value, m_rotation)) { m_rotation = Value; m_Flags |= MCSTEXT_DEPRECATED; } }
};

typedef McsArray<mcsText, const mcsText&> mcsTextsArray;