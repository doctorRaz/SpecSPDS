﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct McsEntityGeometry;

//==============================================================================
struct mcsRepeatedShape
{
	McsEntityGeometry path; // Ru: Путь / En: Path
	double            rLineLength; // Ru: Длина линии / En: Line length
	double            rSpaceLength; // Ru: Длина пробела / En: Space length
	double            rGeometryPos; // Ru: Положение массива геометрии относительно начала сегмента. rGeometryPos < rLineLength + rSpaceLength / En: The position of the geometry array relative to the start of the segment. rGeometryPos < rLineLength + rSpaceLength
	mcsGeomEntArray   geometry;

	DECLARE_OBJ_NEWDEL;

	mcsRepeatedShape()
	{
		rLineLength = 0;
		rSpaceLength = 0;
		rGeometryPos = 0;
	}

	MCTYP_API bool operator ==(const mcsRepeatedShape& cmpWith) const;
	MCTYP_API void transformBy(const mcsMatrix& tfm);
	MCTYP_API bool isEqualTo(const mcsRepeatedShape& cw, const mcsTol& tol = mcsGeContext::gTol) const;

	bool operator != (const mcsRepeatedShape& trg) const
	{
		return !operator == (trg);
	}

	MCTYP_API mcsBoundBlock getBoundBlock(bool isOrtho = false) const;
	MCTYP_API bool          intersectBy(const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          intersectBy(const mcsCircArc& ca, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          intersectBy(const mcsEllipArc& ea, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          intersectBy(const mcsSpline& spline, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool          intersectBy(const McsEntityGeometry& otherEnt, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
};

typedef McsArray<mcsHatch, const mcsHatch&> mcsHatchesArray;