﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

//==============================================================================
struct mcOfsCrvHolder
{
	mcsOffsetCurve* pOfsCrv; // is always non-null(!), the curve it points to is the member 'pOriCrv'
protected:
	mcsCurve* pOriCrv; // the curve 'pOfsCrv' keeps pointer to
public:
	//............................................................................

	DECLARE_OBJ_NEWDEL;

	mcOfsCrvHolder()
	{
		pOfsCrv = new mcsOffsetCurve(mcsLine::kXAxis, mcsVector::kZAxis, 0); // ptr mustn't be null
		pOriCrv = NULL;
	}
	//............................................................................
	mcOfsCrvHolder(const mcsOffsetCurve& OC)
	{
		pOfsCrv = NULL; pOriCrv = NULL;
		*this = OC;
	}
	//............................................................................
	mcOfsCrvHolder& operator = (const mcOfsCrvHolder& och)
	{
		if (this != &och)
			*this = *och.pOfsCrv;
		return *this;
	}
	//............................................................................
	mcOfsCrvHolder& operator = (const mcsOffsetCurve& OC)
	{
		if (pOfsCrv == &OC)
			return *this;

		setNull();

		// create new offset curve, with the same params as 'OC',
		// that refers to the copy of curve in the given 'OC'

		double dist = OC.offsetDistance();
		mcsMatrix3d tfm = OC.transformation();
		bool bReversed = !OC.paramDirection();
		mcsVector vNormal = OC.normal();
		mcsInterval ivl;
		OC.getInterval(ivl);

		pOriCrv = (mcsCurve*)OC.curve()->copy();
		pOfsCrv = new mcsOffsetCurve(*pOriCrv, vNormal, dist);
		if (bReversed)
			pOfsCrv->reverseParam();
		pOfsCrv->setInterval(ivl);
		pOfsCrv->transformBy(tfm);

		return *this;
	}
	//............................................................................
	~mcOfsCrvHolder()
	{
		setNull();
	}
	//............................................................................
	void setNull()
	{
		if (pOfsCrv) // 1'st del the ofs curve, then the curve it refers to
			delete pOfsCrv;
		pOfsCrv = NULL;
		if (pOriCrv)
			delete pOriCrv;
		pOriCrv = NULL;
	}
	//............................................................................
	MCTYP_API bool save(IMcsStream* pS) const;
	MCTYP_API bool load(IMcsStream* pS);
};