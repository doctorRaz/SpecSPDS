﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//
#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

class mcsGeomEntArray;
struct McsEntityGeometry;

//==============================================================================
struct mcsObjGeomRef
{
public:

	mcsWorkID idObject;

	mcsMatrix tfm;

protected:
	enum ObjGeomRefFlags
	{
		kDefault = 0x0000,
		kHardReference = 0x0001,
		kNotSnapable = 0x0002,
	};

	int32_t m_lFlags;

	// Ru:
	//    Для временной прорисовки объекта вне контейнера (для редактирования за ручки),
	//    должен реализовывать IMcDbEntity, тут хранится базовый указатель для возможности сборки MapiBaseTypes
	// En:
	//    For temporary rendering of an object outside the container (for editing via grips),
	//    must implement IMcDbEntity, here stores the base pointer for MapiBaseTypes assembly capability
	IMcObjectPtr m_pTmpObj;

public:
	MCTYP_API mcsObjGeomRef();
	MCTYP_API mcsObjGeomRef(const mcsObjGeomRef&);
	MCTYP_API ~mcsObjGeomRef();

	MCTYP_API void setTmpObj(IMcDbEntity* pTmpDBE);
	MCTYP_API IMcDbEntityPtr getTmpObj() const;

	// Ru:
	//    возвращает объект, из которого отдаётся геометрия (с учетом getTmpObj())
	// En:
	//    returns the object from which the geometry is provided (taking into account getTmpObj())
	MCTYP_API IMcDbEntityPtr getObject() const;

	void setHard(bool isHard)
	{
		if (isHard)
			m_lFlags |= kHardReference;
		else
			m_lFlags &= ~kHardReference;
	}

	bool isHard() const
	{
		return ((m_lFlags & kHardReference) != 0);
	}

	void setSnapable(bool isSnapable)
	{
		if (isSnapable)
			m_lFlags &= ~kNotSnapable;
		else
			m_lFlags |= kNotSnapable;
	}

	bool isSnapable() const
	{
		return ((m_lFlags & kNotSnapable) == 0);
	}

	bool operator == (const mcsObjGeomRef& cw) const { return isEqualTo(cw); }
	bool operator != (const mcsObjGeomRef& cw) const { return !isEqualTo(cw); }

	MCTYP_API void transformBy(const mcsMatrix& tfm);
	MCTYP_API bool isEqualTo(const mcsObjGeomRef& cw, const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API mcsBoundBlock getBoundBlock(bool fOrtho = false) const;
	MCTYP_API double distanceTo(const mcsPoint& pnt, mcsPoint* pNearest = NULL) const;
	MCTYP_API bool getOsnapPoints(McOsnapMode osnapMode, const mcsPoint3d& pickPoint, const mcsPoint3d& lastPoint, mcsPoint3dArray& snapPoints, double rAperture = 0) const;

	MCTYP_API bool intersectBy(const McsEntityGeometry& otherEnt, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCTYP_API bool intersectBy(const mcsCurve& curve, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);

	MCTYP_API bool getGeometry(OUT mcsGeomEntArray&) const;

	enum TfmMatrixType
	{
		kTfmSrcObj = 0x0001, // Ru: собственная матрицы src-объекта / En: own matrix of the src-object
		kTfmGeomRef = 0x0002, // Ru: матрица геометрической ссылки - mcsObjGeomRef::tfm / En: geometric reference matrix - mcsObjGeomRef::tfm
	};

	// Ru:
	//    Метод отдаёт геометрию с учетом указанных в dwRequiredTfmsMask матриц трансформации,
	//    допустимы значения из множества mcsObjGeomRef::TfmMatrixType
	//    вызов getGeometry соответствует маске dwRequiredTfmsMask = kTfmSrcObj | kTfmGeomRef
	// En:
	//    The method returns geometry considering the transformation matrices specified in dwRequiredTfmsMask,
	//    valid values are from the mcsObjGeomRef::TfmMatrixType set
	//    calling getGeometry corresponds to the mask dwRequiredTfmsMask = kTfmSrcObj | kTfmGeomRef
	MCTYP_API bool getGeometryEx(OUT mcsGeomEntArray&, uint32_t dwRequiredTfmsMask) const;
};