﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
#pragma message("Use " __FILE__)
#endif


// mesh 4x3
// vertices, nr*nc = 4*3 = 12:
// 	c0  c1  c2
// r0   0---1---2
// 	 |   |   |
// r1   3---4---5
// 	 |   |   |
// r2   6---7---8
// 	 |   |   |
// r3   9--10--11


struct mcsMeshVertsData
{
protected:
	int               m_nc, m_nr;
	mcsVector3dArray* m_pNormals; // NULL = auto
	mcsColorsArray* m_pColors;  // MAPI colors, NULL = by context

public:
	DECLARE_OBJ_NEWDEL;

	MCGEL_API ~mcsMeshVertsData();
	MCGEL_API mcsMeshVertsData(int nRows, int nCols);
	MCGEL_API mcsMeshVertsData(const mcsMeshVertsData& cf);
	MCGEL_API mcsMeshVertsData& operator =(const mcsMeshVertsData&);

	bool isEmpty() const { return !m_pNormals && !m_pColors; }
	int  totalCount() const { return m_nc * m_nr; }

	MCGEL_API void clear();
	MCGEL_API void purgeColors();
	MCGEL_API void purgeNormals();

	MCGEL_API mcsColorsArray& allocColors(bool bForLoad = false);
	MCGEL_API mcsVector3dArray& allocNormals(bool bForLoad = false);

	MCGEL_API bool isEqualTo(
		const mcsMeshVertsData& cw,
		bool                    fCmpGeomOnly = false,
		const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API void transformBy(const mcsMatrix& tfm);

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);

protected:

	MCTYP_API bool _save_v1(IMcsStream*) const;
	MCTYP_API bool _load_v1(IMcsStream*);

	friend struct mcsMesh;
};
//==============================================================================
enum mcsMeshEdgeSetDirEnum
{
	kRow = 0,
	kCol = 1
};



// mesh 4x3
// edges, ((nr-1)*nc + nr*(nc-1)) = 3*3 + 4*2 = 17:
// 	c0    c1    c2
// r0   +--0--+--1--+
// 	 |     |     |
// 	 8    11    14
// 	 |     |     |
// r1   +--2--+--3--+
// 	 |     |     |
// 	 9    12    15
// 	 |     |     |
// r2   +--4--+--5--+
// 	 |     |     |
// 	10    13    16
// 	 |     |     |
// r3   +--6--+--7--+

struct mcsMeshEdgesData
{
protected:
	int                  m_nc, m_nr;
	mcsLinetypesArray* m_pLineTypes;   // NULL = by context
	mcsIntArray* m_pGsMarkers;    // NULL = no edges detailing in mesh for selection
	mcsBoolArray* m_pVisibilities; // NULL = all grid-edges are visible
	mcsColorsArray* m_pColors;       // MAPI colors, NULL = by context

public:
	DECLARE_OBJ_NEWDEL;

	MCGEL_API ~mcsMeshEdgesData();
	MCGEL_API mcsMeshEdgesData(int nRows, int nCols);
	MCGEL_API mcsMeshEdgesData(const mcsMeshEdgesData& cf);
	MCGEL_API mcsMeshEdgesData& operator =(const mcsMeshEdgesData&);

	bool isEmpty() const { return !m_pLineTypes && !m_pGsMarkers && !m_pVisibilities && !m_pColors; }
	int  totalCount() const { return (m_nr - 1) * m_nc + m_nr * (m_nc - 1); }

	MCGEL_API void clear();
	MCGEL_API void purgeLineTypes();
	MCGEL_API void purgeGsMarkers();
	MCGEL_API void purgeVisibilities();
	MCGEL_API void purgeColors();

	MCGEL_API mcsLinetypesArray& allocLineTypes(bool bForLoad = false);
	MCGEL_API mcsIntArray& allocGsMarkers(bool bForLoad = false);
	MCGEL_API mcsBoolArray& allocVisibilities(bool bForLoad = false);
	MCGEL_API mcsColorsArray& allocColors(bool bForLoad = false);

	MCGEL_API bool isEqualTo(
		const mcsMeshEdgesData& cw,
		bool                    fCmpGeomOnly = false,
		const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API void transformBy(const mcsMatrix& tfm);

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);

protected:

	MCTYP_API bool _save_v1(IMcsStream*) const;
	MCTYP_API bool _load_v1(IMcsStream*);

	friend struct mcsMesh;
};
//==============================================================================



// mesh 4x3
// faces, ((nr-1) * (nc-1)) = 3*2 = 6:
// 	c0  c1  c2
// r0   +---+---+
// 	 | 0 | 1 |
// r1   +---+---+
// 	 | 2 | 3 |
// r2   +---+---+
// 	 | 4 | 5 |
// r3   +---+---+

struct mcsMeshFacesData
{
protected:
	int                 m_nc, m_nr;
	mcsVector3dArray* m_pNormals;        // NULL = Auto
	mcsBoolArray* m_pVisibilities;   // NULL = all grid-edges are visible
	mcsByteArray* m_pTransparencies; // byte per face, 0 (opaque) ... 255 (transparent)
	mcsIntArray* m_pGsMarkers;      // NULL = no faces detailing in mesh for selection
	mcsColorsArray* m_pColors;         // MAPI colors, NULL = by context

public:
	DECLARE_OBJ_NEWDEL;

	MCGEL_API ~mcsMeshFacesData();
	MCGEL_API mcsMeshFacesData(int nRows, int nCols);
	MCGEL_API mcsMeshFacesData(const mcsMeshFacesData& cf);
	MCGEL_API mcsMeshFacesData& operator =(const mcsMeshFacesData&);

	bool isEmpty() const { return !m_pNormals && !m_pVisibilities && !m_pTransparencies && !m_pGsMarkers && !m_pColors; }
	int  totalCount() const { return (m_nr - 1) * (m_nc - 1); }

	MCGEL_API void clear();
	MCGEL_API void purgeNormals();
	MCGEL_API void purgeGsMarkers();
	MCGEL_API void purgeVisibilities();
	MCGEL_API void purgeTransparencies();
	MCGEL_API void purgeColors();

	MCGEL_API mcsVector3dArray& allocNormals(bool bForLoad = false);
	MCGEL_API mcsIntArray& allocGsMarkers(bool bForLoad = false);
	MCGEL_API mcsBoolArray& allocVisibilities(bool bForLoad = false);
	MCGEL_API mcsByteArray& allocTransparencies(bool bForLoad = false);
	MCGEL_API mcsColorsArray& allocColors(bool bForLoad = false);

	MCGEL_API bool isEqualTo(
		const mcsMeshFacesData& cw,
		bool                    fCmpGeomOnly = false,
		const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API void transformBy(const mcsMatrix& tfm);

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);

protected:

	MCTYP_API bool _save_v1(IMcsStream*) const;
	MCTYP_API bool _load_v1(IMcsStream*);

	friend struct mcsMesh;
};
//==============================================================================



enum ShellInternalEdgesHideMethod
{
	kMcHideEdgesNone = 0,
	kMcHideEdgesByCounting, // Ru: скрывает все рёбра, которые используются в сетке более двух раз / En: hides all edges that are used in the mesh more than twice
	kMcHideEdgesByNormals, // Ru: скрывает ребра, у которых на стыке нормали соседних граней образуют угол больше некоторого порогового значения / En: hides edges where the angle between normals of adjacent faces exceeds a certain threshold value
	kMcHideEdgesAll, // Ru: скрывает все рёбра / En: hides all edges
};
//==============================================================================

enum VerticesOptimizeMode
{
	kMcVtxOptMode_None = 0, // без оптимизации
	kMcVtxOptMode_OnTheFly, // оптимизировать на лету, не возвращать результат оптимизации
	kMcVtxOptMode_ReturnRes, // оптимизировать и вернуть результат оптимизации
};


// Ru:
//    Функция генерирует массив видимостей рёбер сетки на основе данных о нормалях её полигонов.
//    Нормали полигонов вычисляются на основе вершин полигонов. (TODO: учитывать данные нормалей на входе)
// En:
//    The function generates an array of mesh edge visibilities based on polygon normal data.
//    Polygon normals are calculated from polygon vertices. (TODO: consider input normal data)
MCGEL_API
bool mcGenerateEdgeVisibilitiesByNormals(
	IN OUT mcsPoint3dArray& points,  // "OUT" if eVtxOptimizeMode = kMcVtxOptMode_ReturnRes
	IN OUT mcsIntArray&     indices, // "OUT" if eVtxOptimizeMode = kMcVtxOptMode_ReturnRes
	OUT mcsByteArray&       edgeVisibilities,
	IN VerticesOptimizeMode eVtxOptimizeMode,
	IN OPTIONAL double      dSameVtxTol = McGeContext::g3dTol.equalPoint());

// Ru:
//    То же, что и функция выше, но без оптимизации данных вершин.
// En:
//    Same as the function above, but without vertex data optimization.
MCGEL_API
bool mcGenerateEdgeVisibilitiesByNormals_noVtxOpt(
	IN const mcsPoint3dArray& points,
	IN const mcsIntArray& indices,
	OUT mcsByteArray& edgeVisibilities);

// Ru:
//    Функция генерирует массив видимостей рёбер сетки на основе данных о количестве раз, которое ребро используется в сетке.
// En:
//    The function generates an array of mesh edge visibilities based on data about the number of times an edge is used in the mesh.
MCGEL_API
bool mcGenerateEdgeVisibilitiesByCount(
	IN const mcsPoint3dArray& points,
	IN const mcsIntArray& indices,
	OUT mcsByteArray& edgeVisibilities);

//==============================================================================



struct mcsMesh
{
protected:
	int               m_nc, m_nr;
	mcsPoint3dArray   m_points;

	// data for the shell-type
	// size of pShellNormals must be equal to the size of points
	// sizeof of pShellIndices must be multiple of 3 and must contain integers that are indices in
	// the <points> member;
	// each triple of indices defines vertices for the triangular piece of a shell

	mcsVector3dArray* m_pShellNormals;
	mcsIntArray* m_pShellIndices;
	mcsByteArray* m_pShellEdgeVisibilities;
	ShellInternalEdgesHideMethod m_shellEdgesHideMethod;

	mcsMeshVertsData* m_pVD;
	mcsMeshEdgesData* m_pED;
	mcsMeshFacesData* m_pFD;

public:
	DECLARE_OBJ_NEWDEL;

	MCGEL_API mcsMesh();
	MCGEL_API mcsMesh(const mcsMesh&);
	MCGEL_API mcsMesh(int nRows, int nCols);
	MCGEL_API ~mcsMesh();

	MCGEL_API bool init(int nRows, int nCols);
	MCGEL_API mcsMesh& operator = (const mcsMesh&);

	// {{ shell-type support

	MCGEL_API bool initForShell(
		const mcsPoint3dArray& vertices,
		const mcsVector3dArray& normals,
		const mcsUInt32Array& facesIndices);

	MCGEL_API bool initForShell(
		int nVertices, const mcsPoint* pVertices,
		int nNormals, const mcsVector* pNormals,
		int nIndices, const uint32_t* pIndices);

	bool isShell() const { return NULL != m_pShellIndices; }

	// call the following methods only if object is of the shell-type
	const mcsPoint3dArray& shellVertices() const { return m_points; }
	const mcsVector3dArray& shellNormals() const { return *m_pShellNormals; }
	const mcsIntArray& shellIndices() const { return *m_pShellIndices; }
	const mcsByteArray& shellEdgeVisibilities() const { return *m_pShellEdgeVisibilities; }

	MCGEL_API bool hideShellInternalEdges(ShellInternalEdgesHideMethod hideMethod);
	MCGEL_API void showShellInternalEdges();

protected:

	MCGEL_API mcsVector3dArray& allocNormalsForShell(int nNormals = 0);
	MCGEL_API mcsIntArray& allocIndicesForShell(int nIndices = 0);
	MCGEL_API mcsByteArray& allocEdgeVisibilitiesForShell(int nEdges = 0);

	MCGEL_API bool hideShellInternalEdgesByCounting();
	MCGEL_API bool hideShellInternalEdgesByNormals(IN OPTIONAL VerticesOptimizeMode eVtxOptimizeMode = kMcVtxOptMode_None, IN OPTIONAL double dSameVtxTol = McGeContext::g3dTol.equalPoint());
	MCGEL_API bool hideAllShellInternalEdges();
	MCGEL_API int  getNumShellEdges() const;

public:
	// }} shell-type support

	int            numRows() const { return m_nr; }
	int            numCols() const { return m_nc; }

	bool           hasVertsData() const { return !!m_pVD; }
	bool           hasEdgesData() const { return !!m_pED; }
	bool           hasFacesData() const { return !!m_pFD; }

	bool           hasVertNormals() const { return m_pVD && m_pVD->m_pNormals; }
	bool           hasVertColors() const { return m_pVD && m_pVD->m_pColors; }

	bool           hasEdgeLinetypes() const { return m_pED && m_pED->m_pLineTypes; }
	bool           hasEdgeVisibilities() const { return m_pED && m_pED->m_pVisibilities; }
	bool           hasEdgeGsMarkers() const { return m_pED && m_pED->m_pGsMarkers; }
	bool           hasEdgeColors() const { return m_pED && m_pED->m_pColors; }

	bool           hasFaceNormals() const { return m_pFD && m_pFD->m_pNormals; }
	bool           hasFaceVisibilities() const { return m_pFD && m_pFD->m_pVisibilities; }
	bool           hasFaceTransparencies() const { return m_pFD && m_pFD->m_pTransparencies; }
	bool           hasFaceGsMarkers() const { return m_pFD && m_pFD->m_pGsMarkers; }
	bool           hasFaceColors() const { return m_pFD && m_pFD->m_pColors; }

	MCGEL_API void clear();

	// resets V/E/F to be default
	MCGEL_API void purgeVertsData();
	MCGEL_API void purgeEdgesData();
	MCGEL_API void purgeFacesData();

	MCGEL_API void purgeVertNormals();
	MCGEL_API void purgeVertColors();

	MCGEL_API void purgeEdgeLinetypes();
	MCGEL_API void purgeEdgeVisibilities();
	MCGEL_API void purgeEdgeGsMarkers();
	MCGEL_API void purgeEdgeColors();

	MCGEL_API void purgeFaceNormals();
	MCGEL_API void purgeFaceVisibilities();
	MCGEL_API void purgeFaceTransparencies();
	MCGEL_API void purgeFaceGsMarkers();
	MCGEL_API void purgeFaceColors();

	MCGEL_API bool isEqualTo(
		const mcsMesh& cw,
		bool           fCmpGeomOnly = false,
		const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API void transformBy(const mcsMatrix& tfm);
	MCGEL_API mcsBoundBlock getBoundBlock(bool fOrtho = false) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);

protected:

	MCTYP_API bool _save_v1(IMcsStream*) const;
	MCTYP_API bool _load_v1(IMcsStream* pS, WORD vMinor);

public:

	MCTYP_API Mc3dImagePtr getAsImage() const;
	MCTYP_API HRESULT      setFromImage(Mc3dImage* pFrom);

	MCGEL_API int32_t calcShellSize() const;


	//............................................................................
	// basic grid coordinates control (vertices)

	// num of verts = numRows * numCols; see numeration at mcsMeshVerticesData definition
	// num of edges = (numRows - 1) * numCols + numRows * (numCols - 1); see numeration at mcsMeshEdgesData definition
	// num of faces = (numRows - 1) * (numCols - 1); see numeration at mcsMeshFacesData definition

	MCGEL_API mcsPoint& pointAt(int iRow, int iCol);
	MCGEL_API const mcsPoint& pointAt(int iRow, int iCol) const;
	MCGEL_API mcsPoint* operator [] (int iRow);       // valid range: 0..nRows-1
	MCGEL_API const mcsPoint* operator [] (int iRow) const; // valid range: 0..nRows-1

	mcsPoint* pointsData() { return m_points.GetData(); }
	const mcsPoint* pointsData() const { return m_points.GetData(); }

	//............................................................................
	// vertices addon control

	MCGEL_API mcsVector& vertexNormalAt(int iRow, int iCol);
	MCGEL_API const mcsVector& vertexNormalAt(int iRow, int iCol) const;

	MCGEL_API mcsColor& vertexColorAt(int iRow, int iCol);
	MCGEL_API const mcsColor& vertexColorAt(int iRow, int iCol) const;

	MCGEL_API mcsVector* vertNormals();       // valid range: 0..(nRows*nCols)-1
	MCGEL_API const mcsVector* vertNormals() const; // valid range: 0..(nRows*nCols)-1
	MCGEL_API mcsVector* vertNormalsAtRow(int iRow);       // valid range: 0..nCols-1
	MCGEL_API const mcsVector* vertNormalsAtRow(int iRow) const; // valid range: 0..nCols-1

	MCGEL_API mcsColor* vertColors();       // valid range: 0..(nRows*nCols)-1
	MCGEL_API const mcsColor* vertColors() const; // valid range: 0..(nRows*nCols)-1
	MCGEL_API mcsColor* vertColorsAtRow(int iRow);       // valid range: 0..nCols-1
	MCGEL_API const mcsColor* vertColorsAtRow(int iRow) const;  // valid range: 0..nCols-1

	//............................................................................
	// edges addon control

	// eDir   - defines edges set - row of edges or column of edges,
	// idxDir - defines index of row or column depends on eDir value

	MCGEL_API mcsLinetype& edgeLinetypeAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir);
	MCGEL_API const mcsLinetype& edgeLinetypeAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir) const;

	MCGEL_API int& edgeGsMarkerAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir);
	MCGEL_API const int& edgeGsMarkerAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir) const;

	MCGEL_API bool& edgeVisibilityAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir);
	MCGEL_API const bool& edgeVisibilityAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir) const;

	MCGEL_API mcsColor& edgeColorAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir);
	MCGEL_API const mcsColor& edgeColorAt(mcsMeshEdgeSetDirEnum eDir, int idxDir, int idxInDir) const;

	MCGEL_API mcsLinetype* edgeLinetypes();       // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API const mcsLinetype* edgeLinetypes() const; // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API mcsLinetype* edgeLinetypesAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir);       // valid range: 0 .. nRows|nCols-1
	MCGEL_API const mcsLinetype* edgeLinetypesAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir) const; // valid range: 0 .. nRows|nCols-1

	MCGEL_API int* edgeGsMarkers();       // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API const int* edgeGsMarkers() const; // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API int* edgeGsMarkersAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir);       // valid range: 0 .. nRows|nCols-1
	MCGEL_API const int* edgeGsMarkersAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir) const; // valid range: 0 .. nRows|nCols-1

	MCGEL_API bool* edgeVisibilities();       // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API const bool* edgeVisibilities() const; // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API bool* edgeVisibilitiesAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir);       // valid range: 0 .. nRows|nCols-1
	MCGEL_API const bool* edgeVisibilitiesAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir) const; // valid range: 0 .. nRows|nCols-1

	MCGEL_API mcsColor* edgeColors();       // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API const mcsColor* edgeColors() const; // valid range: 0 .. (nCols-1)*nRows + nCols*(nRows-1) - 1
	MCGEL_API mcsColor* edgeColorsAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir);       // valid range: 0 .. nRows|nCols-1
	MCGEL_API const mcsColor* edgeColorsAtDir(mcsMeshEdgeSetDirEnum eDir, int idxDir) const; // valid range: 0 .. nRows|nCols-1

	//............................................................................
	// faces addon control

	MCGEL_API mcsVector& faceNormalAt(int iRow, int iCol);
	MCGEL_API const mcsVector& faceNormalAt(int iRow, int iCol) const;

	MCGEL_API int& faceGsMarkerAt(int iRow, int iCol);
	MCGEL_API const int& faceGsMarkerAt(int iRow, int iCol) const;

	MCGEL_API bool& faceVisibilityAt(int iRow, int iCol);
	MCGEL_API const bool& faceVisibilityAt(int iRow, int iCol) const;

	MCGEL_API::byte& faceTransparencyAt(int iRow, int iCol); // 0 - opaque, 255 - fully transparent
	MCGEL_API const ::byte& faceTransparencyAt(int iRow, int iCol) const;

	MCGEL_API mcsColor& faceColorAt(int iRow, int iCol);
	MCGEL_API const mcsColor& faceColorAt(int iRow, int iCol) const;

	MCGEL_API mcsVector* faceNormals();       // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API const mcsVector* faceNormals() const; // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API mcsVector* faceNormalsAtRow(int iRow);       // valid range: 0 .. nCols-1
	MCGEL_API const mcsVector* faceNormalsAtRow(int iRow) const; // valid range: 0 .. nCols-1

	MCGEL_API int* faceGsMarkers();       // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API const int* faceGsMarkers() const; // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API int* faceGsMarkersAtRow(int iRow);       // valid range: 0 .. nCols-1
	MCGEL_API const int* faceGsMarkersAtRow(int iRow) const; // valid range: 0 .. nCols-1

	MCGEL_API bool* faceVisibilities();       // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API const bool* faceVisibilities() const; // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API bool* faceVisibilitiesAtRow(int iRow);       // valid range: 0 .. nCols-1
	MCGEL_API const bool* faceVisibilitiesAtRow(int iRow) const; // valid range: 0 .. nCols-1

	MCGEL_API::byte* faceTransparencies();       // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API const ::byte* faceTransparencies() const; // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API::byte* faceTransparenciesAtRow(int iRow);       // valid range: 0 .. nCols-1
	MCGEL_API const ::byte* faceTransparenciesAtRow(int iRow) const; // valid range: 0 .. nCols-1

	MCGEL_API mcsColor* faceColors();       // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API const mcsColor* faceColors() const; // valid range: 0 .. (nRows-1)*(nCols-1)
	MCGEL_API mcsColor* faceColorsAtRow(int iRow);       // valid range: 0 .. nCols-1
	MCGEL_API const mcsColor* faceColorsAtRow(int iRow) const; // valid range: 0 .. nCols-1

protected:

	MCGEL_API mcsMeshVertsData& vd();
	MCGEL_API mcsVector3dArray& vd_n();
	MCGEL_API mcsColorsArray& vd_c();
	MCGEL_API const mcsVector3dArray& vd_n() const;
	MCGEL_API const mcsColorsArray& vd_c() const;

	MCGEL_API mcsMeshEdgesData& ed();
	MCGEL_API mcsLinetypesArray& ed_lt();
	MCGEL_API mcsIntArray& ed_gs();
	MCGEL_API mcsBoolArray& ed_v();
	MCGEL_API mcsColorsArray& ed_c();
	MCGEL_API const mcsLinetypesArray& ed_lt() const;
	MCGEL_API const mcsIntArray& ed_gs() const;
	MCGEL_API const mcsBoolArray& ed_v() const;
	MCGEL_API const mcsColorsArray& ed_c() const;

	MCGEL_API mcsMeshFacesData& fd();
	MCGEL_API mcsVector3dArray& fd_n();
	MCGEL_API mcsIntArray& fd_gs();
	MCGEL_API mcsBoolArray& fd_v();
	MCGEL_API mcsByteArray& fd_t();
	MCGEL_API mcsColorsArray& fd_c();
	MCGEL_API const mcsVector3dArray& fd_n() const;
	MCGEL_API const mcsIntArray& fd_gs() const;
	MCGEL_API const mcsBoolArray& fd_v() const;
	MCGEL_API const mcsByteArray& fd_t() const;
	MCGEL_API const mcsColorsArray& fd_c() const;
};

typedef McsArray<mcsMesh> mcsMeshArray;
