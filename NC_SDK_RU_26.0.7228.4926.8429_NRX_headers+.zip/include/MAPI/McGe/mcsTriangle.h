﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct mcsTorusImpl;

//==============================================================================
struct mcsTriangle
{
	mcsPoint pt[3];

	mcsTriangle(const mcsPoint& p1, const mcsPoint& p2, const mcsPoint& p3) {
		set(p1, p2, p3);
	}

	mcsTriangle() {
	}

	~mcsTriangle() {
	}

	void set(const mcsPoint& p1, const mcsPoint& p2, const mcsPoint& p3) {
		pt[0] = p1;
		pt[1] = p2;
		pt[2] = p3;
	}

	mcsTriangle(const mcsTriangle& cf) {
		*this = cf;
	}

	mcsTriangle& operator=(const mcsTriangle& cf)
	{
		if (this == &cf)
			return *this;

		pt[0] = cf.pt[0];
		pt[1] = cf.pt[1];
		pt[2] = cf.pt[2];
		return *this;
	}

	DECLARE_OBJ_NEWDEL;

	void transformBy(const mcsMatrix& tfm)
	{
		pt[0].transformBy(tfm);
		pt[1].transformBy(tfm);
		pt[2].transformBy(tfm);
	}

	MCGEL_API bool isEqualTo(const mcsTriangle& t, const mcsTol& tol = mcsGeContext::gTol) const;

	// ((pt[1] - pt[0]).crossProduct(pt[2] - pt[1])).normal()
	MCGEL_API mcsVector normal() const;

	// Ru:
	//    проверяет, лежит ли проекция точки на плоскость треугольника в пределах его границ
	// En:
	//    checks if the point's projection onto the triangle's plane lies within its boundaries
	MCGEL_API bool isProjInBounds(const mcsPoint& pt, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API bool intersectBy(const mcsLinearEntity& axis, OUT mcsPoint& crossPoint, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;
	MCGEL_API mcsBoundBlock getBoundBlock() const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
};

typedef McsArray<mcsTriangle, const mcsTriangle&> mcsTrianglesArray;