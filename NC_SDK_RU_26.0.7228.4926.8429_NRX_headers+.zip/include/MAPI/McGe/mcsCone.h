﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//
#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct mcsConeImpl;
class McGeCone;

//==============================================================================
struct mcsCone
{
private:
#ifdef _MCEYE
public:
#endif
	mcsConeImpl* m_pImpl;

public:
	MCGEL_API mcsCone();
	MCGEL_API mcsCone(const mcsCone& t);
	MCGEL_API mcsCone(const mcsGeCone& cone);

	MCGEL_API ~mcsCone();

	MCGEL_API const McGeCone& asMcsGeCone() const;

	DECLARE_OBJ_NEWDEL;

	MCGEL_API mcsPoint      basept() const;
	MCGEL_API mcsVector     axis() const;
	MCGEL_API double        startR() const;
	MCGEL_API double        endR() const;
	MCGEL_API double        height() const;
	MCGEL_API double        halfAng() const;

	MCGEL_API bool getData(
		OUT OPTIONAL mcsPoint* pBasePt,
		OUT OPTIONAL mcsVector* pDirAxis,
		OUT OPTIONAL double* pRStart,
		OUT OPTIONAL double* pREnd,
		OUT OPTIONAL double* pH) const;

	MCGEL_API mcsPoint apex() const;

	MCGEL_API bool setData(
		IN const mcsPoint& BasePt,
		IN const mcsVector& DirAxis,
		IN double           RStart,
		IN double           REnd,
		IN double           H);

	MCGEL_API mcsCone& set(const mcsGeCone& cone);

	MCGEL_API bool setData(
		IN const mcsPoint& BasePt,
		IN const mcsVector& DirAxis,
		IN double           RStart,
		IN double           halfAng);

	MCGEL_API bool isInner() const;
	MCGEL_API void setInner(bool bInnerSurf);

	MCGEL_API void setInfinite(bool bInfinite);
	MCGEL_API bool isInfinite() const;

	MCGEL_API void          transformBy(const mcsMatrix& tfm);
	MCGEL_API void          reverseAxis();
	MCGEL_API bool          isEqualTo(const mcsCone& t, const mcsTol& tol = mcsGeContext::gTol) const;
	MCGEL_API mcsCone& operator = (const mcsCone&);
	MCGEL_API mcsCone& operator = (const mcsGeCone&);

	MCGEL_API bool          intersectBy(const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API bool intersectBy(
		const mcsLinearEntity& axis,
		OUT mcsPoint3dArray& crossPoints,
		OUT OPTIONAL mcsVector3dArray* pNormals, // = NULL,
		IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API mcsBoundBlock getBoundBlock() const;

	MCTYP_API bool          save(IMcsStream*) const;
	MCTYP_API bool          load(IMcsStream*);
};

typedef McsArray<mcsCone, const mcsCone&> mcsConesArray;