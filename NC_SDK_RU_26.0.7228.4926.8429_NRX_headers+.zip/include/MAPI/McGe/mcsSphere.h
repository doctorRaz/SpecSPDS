﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct mcsSphereImpl;
class McGeSphere;

struct mcsSphere
{
private:
#ifdef _MCEYE
public:
#endif
	mcsSphereImpl* m_pImpl;

public:
	MCGEL_API mcsSphere();
	MCGEL_API mcsSphere(const mcsSphere& t);
	MCGEL_API mcsSphere(const mcsGeSphere& sphere);

	MCGEL_API ~mcsSphere();

	MCGEL_API const McGeSphere& asMcsGeSphere() const;

	DECLARE_OBJ_NEWDEL;

	MCGEL_API mcsPoint      center() const;
	MCGEL_API double        radius() const;

	MCGEL_API bool getData(OUT OPTIONAL mcsPoint* pCenter, OUT OPTIONAL double* pRadius) const;
	MCGEL_API bool setData(IN const mcsPoint& center, IN double radius);
	MCGEL_API mcsSphere& set(const mcsGeSphere& sphere);

	MCGEL_API bool isInner() const;
	MCGEL_API void setInner(bool bInnerSurf);

	MCGEL_API void          transformBy(const mcsMatrix& tfm);
	MCGEL_API bool          isEqualTo(const mcsSphere& t, const mcsTol& tol = mcsGeContext::gTol) const;
	MCGEL_API mcsSphere& operator = (const mcsSphere&);
	MCGEL_API mcsSphere& operator = (const mcsGeSphere& sphere);
	MCGEL_API double        distanceTo(const mcsPoint& pt) const; // negative, if inside
	MCGEL_API double        distanceTo(const mcsPlane& plane) const; // negative, if plane crosses sphere

	MCGEL_API bool isArgInside(const mcsSphere& s) const;
	MCGEL_API bool isArgOutside(const mcsSphere& s) const;

	MCGEL_API bool intersectBy(IN const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API bool intersectBy(
		const mcsLinearEntity& axis,
		OUT mcsPoint3dArray& crossPoints,
		OUT OPTIONAL mcsVector3dArray* pNormals, // = NULL,
		IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API mcsBoundBlock getBoundBlock() const;

	MCTYP_API bool          save(IMcsStream*) const;
	MCTYP_API bool          load(IMcsStream*);
};

typedef McsArray<mcsSphere, const mcsSphere&> mcsSpheresArray;