﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//
#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct mcsTorusImpl;
class McGeTorus;

//==============================================================================
struct mcsTorus
{
private:
#ifdef _MCEYE
public:
#endif
	mcsTorusImpl* m_pImpl;

public:
	MCGEL_API mcsTorus();
	MCGEL_API mcsTorus(const mcsTorus& t);
	MCGEL_API mcsTorus(const mcsGeTorus& torus);

	MCGEL_API ~mcsTorus();

	MCGEL_API const McGeTorus& asMcsGeTorus() const;

	DECLARE_OBJ_NEWDEL;

	MCGEL_API const  mcsCircArc& path() const;
	MCGEL_API double        minR() const;
	MCGEL_API double        maxR() const;
	MCGEL_API mcsPoint      center() const;
	MCGEL_API mcsVector     axis() const;

	MCGEL_API bool getData(
		OUT OPTIONAL mcsCircArc* pPathAxis,
		OUT OPTIONAL double* pPathRadius) const;

	MCGEL_API bool setData(
		IN const mcsCircArc& PathAxis,
		IN double            PathRadius);

	MCGEL_API mcsTorus& set(const mcsGeTorus& torus);

	MCGEL_API bool isInner() const;
	MCGEL_API void setInner(bool bInnerSurf);

	MCGEL_API void          transformBy(const mcsMatrix& tfm);
	MCGEL_API void          reverseAxis();
	MCGEL_API bool          isEqualTo(const mcsTorus& t, const mcsTol& tol = mcsGeContext::gTol) const;
	MCGEL_API mcsTorus& operator = (const mcsTorus&);
	MCGEL_API mcsTorus& operator = (const mcsGeTorus& torus);

	MCGEL_API bool intersectBy(const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API bool intersectBy(
		const mcsLinearEntity& axis,
		OUT mcsPoint3dArray& crossPoints,
		OUT OPTIONAL mcsVector3dArray* pNormals, // = NULL,
		IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API mcsBoundBlock getBoundBlock() const;

	MCTYP_API bool          save(IMcsStream*) const;
	MCTYP_API bool          load(IMcsStream*);
};

typedef McsArray<mcsTorus, const mcsTorus&> mcsTorusesArray;