﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

struct mcsCylImpl;
class McGeCylinder;

//==============================================================================
struct mcsCylinder
{
private:
#ifdef _MCEYE
public:
#endif
	mcsCylImpl* m_pImpl;

public:
	MCGEL_API mcsCylinder();
	MCGEL_API mcsCylinder(const mcsCylinder& t);
	MCGEL_API mcsCylinder(const mcsGeCylinder& cylinder);

	MCGEL_API ~mcsCylinder();

	MCGEL_API const McGeCylinder& asMcsGeCylinder() const;

	DECLARE_OBJ_NEWDEL;

	MCGEL_API mcsPoint      basept() const;
	MCGEL_API mcsVector     axis() const;
	MCGEL_API double        radius() const;
	MCGEL_API double        length() const;

	MCGEL_API bool getData(
		OUT OPTIONAL mcsPoint* pBasePt,
		OUT OPTIONAL mcsVector* pDirAxis,
		OUT OPTIONAL double* pRadius,
		OUT OPTIONAL double* pLength) const;

	MCGEL_API bool setData(
		IN const mcsPoint& BasePt,
		IN const mcsVector& DirAxis,
		IN double           Radius,
		IN double           Length);

	MCGEL_API mcsCylinder& set(const mcsGeCylinder& cylinder);

	MCGEL_API bool isInner() const;
	MCGEL_API void setInner(bool bInnerSurf);

	MCGEL_API void setInfinite(bool bInfinite);
	MCGEL_API bool isInfinite() const;

	MCGEL_API mcsCylinder& transformBy(const mcsMatrix& tfm);
	MCGEL_API void          reverseAxis();
	MCGEL_API bool          isEqualTo(const mcsCylinder& t, const mcsTol& tol = mcsGeContext::gTol) const;
	MCGEL_API mcsCylinder& operator = (const mcsCylinder&);
	MCGEL_API mcsCylinder& operator = (const mcsGeCylinder&);

	MCGEL_API bool intersectBy(const mcsLinearEntity& axis, OUT mcsPoint3dArray& crossPoints, IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API bool intersectBy(
		const mcsLinearEntity& axis,
		OUT mcsPoint3dArray& crossPoints,
		OUT OPTIONAL mcsVector3dArray* pNormals, // = NULL,
		IN OPTIONAL const mcsTol& tol = mcsGeContext::gTol) const;

	MCGEL_API mcsBoundBlock getBoundBlock() const;

	MCTYP_API bool          save(IMcsStream*) const;
	MCTYP_API bool          load(IMcsStream*);
};

typedef McsArray<mcsCylinder, const mcsCylinder&> mcsCylindersArray;