﻿//
// Копирайт (С) 2019, ООО «Нанософт разработка». Все права защищены.
// 
// Данное программное обеспечение, все исключительные права на него, его
// документация и сопроводительные материалы принадлежат ООО «Нанософт разработка».
// Данное программное обеспечение может использоваться при разработке и входить
// в состав разработанных программных продуктов при соблюдении условий
// использования, оговоренных в «Лицензионном договоре присоединения
// на использование программы для ЭВМ «Платформа nanoCAD»».
// 
// Данное программное обеспечение защищено в соответствии с законодательством
// Российской Федерации об интеллектуальной собственности и международными
// правовыми актами.
// 
// Используя данное программное обеспечение,  его документацию и
// сопроводительные материалы вы соглашаетесь с условиями использования,
// указанными выше. 
//

#pragma once

#ifdef _VERBOSEHEADERS_
	#pragma message("Use " __FILE__)
#endif

//==============================================================================
struct mcsHatch
{
	enum Style
	{
		kNormal = 0,
		kOuter = 1,
		kIgnore = 2
	};
	enum PatternType
	{
		kUserDefined = 0, // Ru: линиями (angle, spacing, patternDouble) / En: lines (angle, spacing, patternDouble)
		kPreDefined = 1, // Ru: по шаблону (patternName, angle, patternScale) / En: by template (patternName, angle, patternScale)
		kCustomDefined = 2
	};
	enum ObjectType
	{
		kHatchObject = 0,
		kGradientObject = 1,
		kWipeoutObject = 2,
	};
	enum LoopType
	{
		kDefault = 0x0000,
		kExternal = 0x0001,
		kPolyline = 0x0002,
		kDerived = 0x0004,
		kTextbox = 0x0008,
		kOutermost = 0x0010,
		kNotClosed = 0x0020,
		kSelfIntersecting = 0x0040,
		kTextIsland = 0x0080,
		kDuplicate = 0x0100,
		kIsAnnotative = 0x0200,
		kDoesNotSupportScale = 0x0400,
		kForceAnnoAllVisible = 0x0800,
		kOrientToPaper = 0x1000,
		kIsAnnotativeBlock = 0x2000,

		// System. Mcs only.
		kComposite = 0x80000,
	};
	enum GradientPatternType
	{
		kPreDefinedGradient = 0,
		kUserDefinedGradient = 1
	};
	typedef mcsWorkIDArray mcsHatchAssocContour;
	typedef McsArray<mcsHatchAssocContour, const mcsHatchAssocContour&> mcsHatchAssocContours;

	mcsPolylineArray contours;
	mcsHatchAssocContours assocContours;// Must be the same size as contours, otherwise ignored.
	double           angle;
	double           spacing;// Pattern space. Only for kUserDefined hatch. 0 - for solid hatch.
	Style            hatchStyle;
	PatternType      patternType;
	McsString        patternName;// Only for kPreDefined and kCustomDefined hatches.
	double           patternScale;
	color_t          backgroundColor;
	bool             patternDouble;// Only for kUserDefined hatch. Double patterns apply a second set
	// of hatch lines at 90 degrees to the original hatch lines.
	bool             bAutoOrigin; // Ru: Начало отсчёта штриховки рассчитывается автоматически на основе баунда / En: The hatch pattern origin is calculated automatically based on the bound
	mcsPoint2d       pntOrigin; // Ru: Начало отчсёта штриховки / En: Start of hatching count
	bool isAssociative;
	ObjectType objectType;
	GradientPatternType gradientType;
	McsString gradientName;
	double gradientAngle;
	color_t gradientColor1;
	color_t gradientColor2;
	double gradientColorInterpolation1;
	double gradientColorInterpolation2;
	bool isGradientOneColorMode;
	double shadeTintValue;
	double gradientShift;

	DECLARE_OBJ_NEWDEL;

	MCTYP_API mcsHatch();
	MCTYP_API ~mcsHatch();

	//Constructs simple user defined hatch
	MCTYP_API mcsHatch(const mcsPolyline& _contour, const double _angle, const double _spacing, const bool _patternDouble = false);

	//Full
	MCTYP_API mcsHatch(
		const mcsPolylineArray& _contours,
		LPCTSTR _patternName,
		const double _angle,
		const double _spacing,
		const bool _patternDouble = false,
		const Style _hatchStyle = kNormal,
		const PatternType _patternType = kUserDefined,
		const double _patternScale = 1);

	bool isSolid() const
	{
		if (patternType == kUserDefined && spacing < DEF_TOL || patternType == kPreDefined && 0 == _tcsicmp(patternName, _T("SOLID")))
			return true;
		return false;
	}

	MCTYP_API mcsPoint2d getOrigin() const;

	MCTYP_API bool operator == (const mcsHatch& trg) const;
	MCTYP_API bool isEqualTo(const mcsHatch& cw, const mcsTol& tol = mcsGeContext::gTol) const;

	bool operator != (const mcsHatch& trg) const
	{
		return !operator == (trg);
	}

	MCTYP_API void transformBy(const mcsMatrix& tfm);

	MCTYP_API mcsBoundBlock getBoundBlock(bool isOrtho = false) const;

	MCTYP_API bool save(IMcsStream*) const;
	MCTYP_API bool load(IMcsStream*);
};

typedef McsArray<mcsHatch, const mcsHatch&> mcsHatchesArray;